#include "JAKAZuRobot.h"
#include "jakaAPI.h"
#include <iostream>

int main()
{
    std::cout<<"main-------------------"<<std::endl;
    JAKAZuRobot test;
	test.login_in("192.168.2.200");
	test.power_on();
    return 0;
}

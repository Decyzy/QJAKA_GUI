#include <QCoreApplication>
#include "inc/JAKAZuRobot.h"
#include <iostream>

#define PI 3.1415926

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    JAKAZuRobot test;
    std::cout<<test.login_in("192.168.2.200")<<std::endl;
    test.power_on();
    test.enable_robot();
    JointValue refP;
    refP.jVal[0] = 0*PI/180; refP.jVal[1] = 90 * PI / 180; refP.jVal[2] = -90 * PI / 180;
    refP.jVal[3] = 90 * PI / 180; refP.jVal[4] = 90 * PI / 180; refP.jVal[5] = 0 * PI / 180;
    test.joint_move(&refP, MoveMode::ABS, TRUE, 0.2);

    return a.exec();
}

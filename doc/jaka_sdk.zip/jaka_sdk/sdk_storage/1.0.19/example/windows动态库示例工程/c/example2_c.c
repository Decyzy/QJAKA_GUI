﻿#include "jakaAPI.h"
#include <stdio.h>

int main()
{
	JKHD handle;
	//创建机器人控制句柄  
	create_handler("192.168.2.229", &handle);
	//定义并初始化关JointValue变量  
	JointValue joint_pos  = { 90,50,-70,20,11 - 70,11 };
	//关节空间运动，其中ABS为绝对运动，TRUE代表指令是阻塞的，1代表速度为1rad/s  
	joint_move(&handle, &joint_pos, ABS, TRUE, 1);
	//定义并初始化CartesianPose变量  
	CartesianPose cart;
	cart.tran.x = -115; cart.tran.y = 796; cart.tran.z  = 358;
	cart.rpy.rx = 84; cart.rpy.ry = -12; cart.rpy.rz  = 166;
	//笛卡尔空间运动，其中ABS为绝对运动，FALSE代表指令是非阻塞的，10代表速度为10mm/s  
	linear_move(&handle, &cart,ABS, FALSE, 10);
	return 0;
}

﻿using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection.Metadata;
using System.ComponentModel;

namespace cshapforJakaAPI
{
    class Program
    {
        delegate void CallBackFuncType(int error_code);
        public static void user_error_handle(int error_code)
        {
            switch(error_code)
			{
				case 1:
					{
						Console.WriteLine("case 1");
						break;
					}
				case 2:
					{
						Console.WriteLine("case 2");
						break;
					}
				default:
					{
						Console.WriteLine("case default");
						break;
					}
			}
        }		
		
		class jakaAPI
        {
            [DllImport("jakaAPI.dll", EntryPoint = "create_handler", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
            public static extern int create_handler(char[] ip,ref int handle);
            [DllImport("jakaAPI.dll", EntryPoint = "destory_handler", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
            public static extern int destory_handler(ref int handle);
            [DllImport("jakaAPI.dll", EntryPoint = "power_on", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
            public static extern int power_on(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "power_off", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int power_off(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "shut_down", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int  shut_down(ref int handle);

			[DllImport("jakaAPI.dll", EntryPoint = "enable_robot", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int enable_robot(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "disable_robot", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int disable_robot(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "jog", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int jog(ref int handle, int aj_num, JKTYPE.MoveMode move_mode, JKTYPE.CoordType coord_type, double vel_cmd, double pos_cmd);
			[DllImport("jakaAPI.dll", EntryPoint = "jog_stop", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int jog_stop(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "joint_move", ExactSpelling = false, CallingConvention = CallingConvention.StdCall,CharSet =CharSet.Unicode)]
			public  static extern  int joint_move(ref int handle,  ref JKTYPE.JointValue joint_pos, JKTYPE.MoveMode move_mode, bool is_block, double speed);

			[DllImport("jakaAPI.dll", EntryPoint = "linear_move", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int linear_move(ref int handle, ref JKTYPE.CartesianPose end_pos, JKTYPE.MoveMode move_mode, bool is_block, double speed);
			[DllImport("jakaAPI.dll", EntryPoint = "servo_move_enable", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int servo_move_enable(ref int handle, bool enable);
			[DllImport("jakaAPI.dll", EntryPoint = "servo_j", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int servo_j(ref int handle, ref JKTYPE.JointValue joint_pos, JKTYPE.MoveMode move_mode);
			[DllImport("jakaAPI.dll", EntryPoint = "servo_p", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int servo_p(ref int handle, ref JKTYPE.CartesianPose cartesian_pose, JKTYPE.MoveMode move_mode);
			[DllImport("jakaAPI.dll", EntryPoint = "set_digital_output", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int set_digital_output(ref int handle, JKTYPE.IOType type, int index, bool value);
			[DllImport("jakaAPI.dll", EntryPoint = "set_analog_output", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int set_analog_output(ref int handle, JKTYPE.IOType type, int index, float value);
			[DllImport("jakaAPI.dll", EntryPoint = "get_digital_input", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int get_digital_input(ref int handle, JKTYPE.IOType type, int index, ref bool result);
			[DllImport("jakaAPI.dll", EntryPoint = "get_digital_output", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_digital_output(ref int handle, JKTYPE.IOType type, int index, ref bool result);
			[DllImport("jakaAPI.dll", EntryPoint = "get_analog_input", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_analog_input(ref int handle, JKTYPE.IOType type, int index, ref float result);
			[DllImport("jakaAPI.dll", EntryPoint = "get_analog_output", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int get_analog_output(ref int handle, JKTYPE.IOType type, int index, ref float result);
			[DllImport("jakaAPI.dll", EntryPoint = "is_extio_running", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int is_extio_running(ref int handle, ref bool is_running);
			[DllImport("jakaAPI.dll", EntryPoint = "program_run", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int program_run(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "program_pause", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int program_pause(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "program_resume", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int program_resume(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "program_abort", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int program_abort(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "program_load", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int program_load(ref int handle, char[] file);
			[DllImport("jakaAPI.dll", EntryPoint = "get_loaded_program", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_loaded_program(ref int handle, StringBuilder file);
			[DllImport("jakaAPI.dll", EntryPoint = "get_current_line", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_current_line(ref int handle, ref int curr_line);
			[DllImport("jakaAPI.dll", EntryPoint = "get_program_state", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_program_state(ref int handle, ref JKTYPE.ProgramState status);
			[DllImport("jakaAPI.dll", EntryPoint = "set_rapidrate", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int set_rapidrate(ref int handle, double rapid_rate);
			[DllImport("jakaAPI.dll", EntryPoint = "get_rapidrate", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_rapidrate(ref int handle, ref double rapid_rate);
			[DllImport("jakaAPI.dll", EntryPoint = "set_tool_data", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int set_tool_data(ref int handle, int id, ref JKTYPE.CartesianPose tcp, char[] name);
			[DllImport("jakaAPI.dll", EntryPoint = "set_tool_id", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int set_tool_id(ref int handle, int id);
			[DllImport("jakaAPI.dll", EntryPoint = "get_tool_id", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_tool_id(ref int handle, ref int id);
			[DllImport("jakaAPI.dll", EntryPoint = "set_user_frame_data", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int set_user_frame_data(ref int handle, int id, ref JKTYPE.CartesianPose user_frame, char[] name);
			[DllImport("jakaAPI.dll", EntryPoint = "set_user_frame_id", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int set_user_frame_id(ref int handle, int id);
			[DllImport("jakaAPI.dll", EntryPoint = "get_user_frame_id", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_user_frame_id(ref int handle, ref int id);
			[DllImport("jakaAPI.dll", EntryPoint = "drag_mode_enable", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int drag_mode_enable(ref int handle, bool enable);
			[DllImport("jakaAPI.dll", EntryPoint = "is_in_drag_mode", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int is_in_drag_mode(ref int handle, ref bool in_drag);
			[DllImport("jakaAPI.dll", EntryPoint = "get_robot_state", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_robot_state(ref int handle, ref JKTYPE.RobotState state);
			[DllImport("jakaAPI.dll", EntryPoint = "get_tcp_position", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_tcp_position(ref int handle, ref JKTYPE.CartesianPose tcp_position);
			[DllImport("jakaAPI.dll", EntryPoint = "get_joint_position", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_joint_position(ref int handle, ref JKTYPE.JointValue joint_position);
			[DllImport("jakaAPI.dll", EntryPoint = "is_in_collision", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int is_in_collision(ref int handle, ref bool in_collision);
			[DllImport("jakaAPI.dll", EntryPoint = "is_on_limit", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int is_on_limit(ref int handle, ref bool on_limit);
			[DllImport("jakaAPI.dll", EntryPoint = "is_in_pos", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int is_in_pos(ref int handle, ref bool in_pos);
			[DllImport("jakaAPI.dll", EntryPoint = "collision_recover", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int collision_recover(ref int handle);
			[DllImport("jakaAPI.dll", EntryPoint = "set_collision_level", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int set_collision_level(ref int handle,int level);
			[DllImport("jakaAPI.dll", EntryPoint = "get_collision_level", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int get_collision_level(ref int handle, ref int level);
			[DllImport("jakaAPI.dll", EntryPoint = "kine_inverse", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int kine_inverse(ref int handle, ref JKTYPE.JointValue ref_pos, ref JKTYPE.CartesianPose cartesian_pose, ref JKTYPE.JointValue joint_pos);
			[DllImport("jakaAPI.dll", EntryPoint = "kine_forward", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int kine_forward(ref int handle, ref JKTYPE.JointValue joint_pos, ref JKTYPE.CartesianPose cartesian_pose);
			[DllImport("jakaAPI.dll", EntryPoint = "rpy_to_rot_matrix", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int rpy_to_rot_matrix(ref int handle, ref JKTYPE.Rpy rpy, ref JKTYPE.RotMatrix rot_matrix);
			[DllImport("jakaAPI.dll", EntryPoint = "rot_matrix_to_rpy", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int rot_matrix_to_rpy(ref int handle, ref JKTYPE.RotMatrix rot_matrix, ref JKTYPE.Rpy rpy);
			[DllImport("jakaAPI.dll", EntryPoint = "quaternion_to_rot_matrix", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int quaternion_to_rot_matrix(ref int handle, ref JKTYPE.Quaternion quaternion, ref JKTYPE.RotMatrix rot_matrix);
			[DllImport("jakaAPI.dll", EntryPoint = "rot_matrix_to_quaternion", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int rot_matrix_to_quaternion(ref int handle, ref JKTYPE.RotMatrix rot_matrix, ref JKTYPE.Quaternion quaternion);
			[DllImport("jakaAPI.dll", EntryPoint = "torque_control_enable", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int torque_control_enable(ref int handle, bool enable);
			[DllImport("jakaAPI.dll", EntryPoint = "torque_feedforward", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int torque_feedforward(ref int handle, JKTYPE.TorqueValue tor_val, int grv_flag);
			[DllImport("jakaAPI.dll", EntryPoint = "set_payload", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int set_payload(ref int handle, ref JKTYPE.PayLoad payload);
			[DllImport("jakaAPI.dll", EntryPoint = "get_payload", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

			public static extern int get_payload(ref int handle, ref JKTYPE.PayLoad payload);
            [DllImport("jakaAPI.dll", EntryPoint = "set_error_handler", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
            public static extern int set_error_handler(ref int i, CallBackFuncType func);
			[DllImport("jakaAPI.dll", EntryPoint = "get_sdk_version", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
			public static extern int get_sdk_version(ref int i, StringBuilder version);


		}
        static void Main(string[] args)
        {
			int[] i = new int[2] { 0, 1 };
			//创建机器人控制句柄, 需要将192.168.2.138替换为自己控制器的IP  
			Console.WriteLine(jakaAPI.create_handler("192.168.2.229".ToCharArray(), ref i[0]));
			//创建机器人控制句柄，需要将192.168.2.64替换为自己控制器的IP  
			Console.WriteLine(jakaAPI.create_handler("192.168.2.64".ToCharArray(), ref i[1]));
			//机器人上电  
			Console.WriteLine(jakaAPI.power_on(ref i[0]));
			Console.WriteLine(jakaAPI.power_on(ref i[1]));
			//机器人上使能  
			Console.WriteLine(jakaAPI.enable_robot(ref i[0]));
			Console.WriteLine(jakaAPI.enable_robot(ref i[1]));
			//设置机器人运行倍率  
			Console.WriteLine(jakaAPI.set_rapidrate(ref i[0], 0.6));
			Console.WriteLine(jakaAPI.set_rapidrate(ref i[1], 0.3));

		}
    }
}




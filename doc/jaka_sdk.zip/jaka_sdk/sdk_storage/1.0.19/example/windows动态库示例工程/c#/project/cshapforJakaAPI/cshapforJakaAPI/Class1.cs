﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;
using System.Runtime.InteropServices;


namespace cshapforJakaAPI
{

	public class JKTYPE
	{
		/**
        * @brief 笛卡尔空间位置数据类型
        */
		public struct CartesianTran
		{

			public double x;       ///< x轴坐标，单位mm
			public double y;       ///< y轴坐标，单位mm
			public double z;       ///< z轴坐标，单位mm
		};
		/**
		* @brief 欧拉角姿态数据类型
		*/
		public struct Rpy
		{
			public double rx;  ///< 绕固定轴X旋转角度，单位：rad
			public double ry;  ///< 绕固定轴Y旋转角度，单位：rad
			public double rz;  ///< 绕固定轴Z旋转角度，单位：rad
		};

		/**
		* @brief 四元数姿态数据类型
		*/
		public struct Quaternion
		{
			public double s;
			public double x;
			public double y;
			public double z;
		};

		/**
		 *@brief 笛卡尔空间位姿类型
		 */
		public struct CartesianPose
		{
			public CartesianTran tran;     ///< 笛卡尔空间位置
			public Rpy rpy;             ///< 笛卡尔空间姿态
		};

		/**
		* @brief 旋转矩阵数据类型
		*/
		public struct RotMatrix
		{
			public CartesianTran x;  ///< x轴列分量
			public CartesianTran y;  ///< y轴列分量
			public CartesianTran z; ///< z轴列分量
		};

		/**
		* @brief 程序运行状态枚举类型
		*/
		public enum ProgramState
		{
			PROGRAM_IDLE,       ///< 机器人停止运行
			PROGRAM_RUNNING,    ///< 机器人正在运行
			PROGRAM_PAUSED      ///< 机器人暂停	
		};

		/**
		* @brief 坐标系选择枚举类型
		*/
		public enum CoordType
		{
			COORD_BASE,     ///< 基坐标系
			COORD_JOINT,    ///< 关节空间
			COORD_TOOL      ///< 工具坐标系
		};

		/**
		* @brief jog运动模式枚举
		*/
		public enum MoveMode
		{
			ABS = 0,        ///< 绝对运动
			INCR        ///< 增量运动
		};

		/**
		* @brief 系统监测数据类型
		*/
		public struct SystemMonitorData
		{
			public int scbMajorVersion;            ///<scb主版本号
			public int scbMinorVersion;            ///<scb次版本号
			public int cabTemperature;             ///<控制柜温度	
			public double robotAveragePower;       ///<控制柜总线平均功率
			public double robotAverageCurrent;     ///<控制柜总线平均电流
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public double[] instCurrent;          ///<机器人6个轴的瞬时电流
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public double[] instVoltage;          ///<机器人6个轴的瞬时电压
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public double[] instTemperature;        ///<机器人6个轴的瞬时温度
		};

		/**
		* @brief 负载数据类型
		*/
		public struct PayLoad
		{
			public double mass;                ///<负载质量，单位：kg
			public CartesianTran centroid;      ///<负载质心, 单位：mm
		};

		/**
		* @brief 关节位置数据类型
		*/
		public struct JointValue
		{
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public double[] jVal ;       ///< 6关节位置值，单位：rad	
			//public double jVal0;
		};

		/**
		* @brief IO类型枚举
		*/
		public enum IOType
		{
			IO_CABINET,     ///< 控制柜面板IO
			IO_TOOL,        ///< 工具IO
			IO_EXTEND       ///< 扩展IO
		};

		/**
		* @brief 机器人状态数据
		*/
		public struct RobotState
		{
			public int estoped;       ///< 是否急停
			public int poweredOn;     ///< 是否打开电源
			public int servoEnabled;    ///< 是否使能
		};

		/**
		* @brief 机器人力矩前馈数据
		*/
		public struct TorqueValue
		{
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public double[] jTorque;    ///< 是否使能
		}

		/**
		* @brief 机器人状态监测数据,使用get_robot_status函数更新机器人状态数据
		*/
		public struct RobotStatus
		{
			public int errcode;                                ///< 机器人运行出错时错误编号，0为运行正常，其它为运行异常
			public int inpos;                                  ///< 机器人运动是否到位标志，0为没有到位，1为运动到位
			public int powered_on;                             ///< 机器人是否上电标志，0为没有上电，1为上电
			public int enabled;                                ///< 机器人是否使能标志，0为没有使能，1为使能
			public double rapidrate;                           ///< 机器人运动倍率
			public int protective_stop;                        ///< 机器人是否检测到碰撞，0为没有检测到碰撞，1为检测到碰撞
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 65)]
			public int []dout;								   ///< 机器人控制柜数字输出信号,dout[0]为信号的个数
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
			public int []tio_dout;                             ///< 机器人末端工具数字输出信号,tio_dout[0]为信号的个数
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 65)]
			public double []extio;                             ///< 机器人外部应用数字输出信号,extio[0]为信号的个数
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 65)]
			public int []din;                                  ///< 机器人控制柜数字输入信号,din[0]为信号的个数
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
			public int []tio_din;                              ///< 机器人末端工具数字输入信号,tio_din[0]为信号的个数
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 65)]
			public double []ain;                               ///< 机器人控制柜模拟输入信号,ain[0]为信号的个数
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
			public double []tio_ain;                           ///< 机器人末端工具模拟输入信号,tio_ain[0]为信号的个数
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 65)]
			public double []aout;                              ///< 机器人控制柜模拟输出信号,aout[0]为信号的个数
			public int current_tool_id;                        ///< 机器人目前使用的工具坐标系id
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public double []cartesiantran_position;            ///< 机器人末端所在的笛卡尔空间位置
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public double []joint_position;                    ///< 机器人关节空间位置
			public int on_soft_limit;                          ///< 机器人是否处于限位，0为没有触发限位保护，1为触发限位保护
			public int current_user_id;                        ///< 机器人目前使用的用户坐标系id
			public int drag_status;                            ///< 机器人是否处于拖拽状态，0为没有处于拖拽状态，1为处于拖拽状态
		}

		/**
		* @brief 机器人错误码数据类型
		*/
		public struct ErrorCode
		{
			public long code;                                   ///< 错误码编号
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 120)]
			public char[] message;								///< 错误码对应提示信息
		}
	}
}

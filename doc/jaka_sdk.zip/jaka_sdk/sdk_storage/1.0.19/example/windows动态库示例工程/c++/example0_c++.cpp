﻿#include <iostream>
#include "JAKAZuRobot.h"

int main()
{
	//实例API对象demo 
	JAKAZuRobot demo;
	//登陆控制器，需要将192.168.2.229替换为自己控制器的IP
	demo.login_in("192.168.2.229");
	//机器人上电
	demo.power_on();
	//机器人上使能
	demo.enable_robot();
	//设置机器人运行倍率
	demo.set_rapidrate(0.3);
	return 0;
}

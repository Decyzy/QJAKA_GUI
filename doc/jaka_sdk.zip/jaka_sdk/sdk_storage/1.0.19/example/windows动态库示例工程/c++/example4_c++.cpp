#include <iostream>
#include "JAKAZuRobot.h"


int main()
{
	//实例API对象demo  
	JAKAZuRobot demo;
	//登陆控制器，需要将192.168.2.138替换为自己控制器的IP  
	demo.login_in("192.168.2.229");
	//设置控制器面板index为1的DO为1
	demo.set_digital_output(IO_CABINET, 1, 1);
	BOOL result;
	//获取控制器面板index为1的DO的数值
	demo.get_digital_output(IO_CABINET, 1, &result);
	std::cout << "index 1 :" << result << std::endl;
	//查询扩展IO模块是否存在
	demo.is_extio_running(&result);
	if (result)
		std::cout << "extio exist" << std::endl;
	else
		std::cout << "extio not exist" << std::endl;
	system("pause");
	return 0;
}

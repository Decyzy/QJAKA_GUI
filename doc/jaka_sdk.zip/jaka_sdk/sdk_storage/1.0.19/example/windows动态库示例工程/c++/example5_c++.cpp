#include <iostream>
#include "JAKAZuRobot.h"

#define PI 3.1415926

int main()
{
	//实例API对象demo 
	JAKAZuRobot demo;
	//登陆控制器，需要将192.168.2.229替换为自己控制器的IP
	demo.login_in("192.168.2.229");
	//机器人上电
	demo.power_on();
	//机器人上使能
	demo.enable_robot();
	//定义并初始化关JointValue变量
	JointValue joint_pos = { 90 * PI / 180, 50 * PI / 180, -70 * PI / 180, 20 * PI / 180, 11 * PI / 180, 11 * PI / 180 };
	//关节空间运动，其中ABS代表绝对运动，TRUE代表指令是阻塞的，1代表速度为1rad/s  
	demo.joint_move(&joint_pos, ABS, TRUE, 1);

	joint_pos.jVal[0] = 1; joint_pos.jVal[1] = 1; joint_pos.jVal[2] = 1;
	joint_pos.jVal[3] = 1; joint_pos.jVal[4] = 1; joint_pos.jVal[5] = 1;
	demo.joint_move(&joint_pos, ABS, TRUE, 1);

	for (int i = 0; i < 10; ++i)
	{
		JointValue tmp;
		if (i % 2 == 0)
		{
			tmp = { 1, 2, 1, 2, 1, 2 };
		}
		else
		{
			tmp = { -1, -2, -1, -2, -1, -2 };
		}
		joint_pos = tmp;
		demo.joint_move(&joint_pos, ABS, TRUE, 1);
	}

	//定义并初始化CartesianPose变量
	CartesianPose cart;
	cart.tran.x = -115; cart.tran.y = 796; cart.tran.z = 358;
	cart.rpy.rx = 84; cart.rpy.ry = -12; cart.rpy.rz = 166;
	//笛卡尔空间运动，其中ABS代表绝对运动，FALSE代表指令是非阻塞的，10代表速度为10mm/s    
	demo.linear_move(&cart, ABS, FALSE, 10);
	return 0;
}

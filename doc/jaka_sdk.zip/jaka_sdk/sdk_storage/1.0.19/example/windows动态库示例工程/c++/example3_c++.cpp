﻿#include <iostream>
#include "JAKAZuRobot.h"


int main()
{
	//实例API对象demo  
	JAKAZuRobot demo[2];
	//登陆控制器，需要将192.168.2.138替换为自己控制器的IP  
	demo[0].login_in("192.168.2.138");
	//登陆控制器，需要将192.168.2.64替换为自己控制器的IP  
	demo[1].login_in("192.168.2.64");
	//机器人上电    
	demo[0].power_on();
	demo[1].power_on();
	//机器人上使能    
	demo[0].enable_robot();
	demo[1].enable_robot();
	return 0;
}

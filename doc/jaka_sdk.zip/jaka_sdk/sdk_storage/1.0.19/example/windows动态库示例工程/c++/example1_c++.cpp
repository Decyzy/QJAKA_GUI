﻿#include <iostream>
#include "JAKAZuRobot.h"

void user_error_handle(int error_code)
{
	std::cout << error_code << std::endl;
}

int main()
{
	//实例API对象demo 
	JAKAZuRobot demo;
	//登陆控制器，需要将192.168.2.229替换为自己控制器的IP
	demo.login_in("192.168.2.229");
	//机器人上电
	demo.power_on();
	//机器人上使能
	demo.enable_robot();
	//设置用户异常回调函数
	demo.set_error_handler(user_error_handle);
	return 0;
}
